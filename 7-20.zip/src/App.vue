<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style lang="less">
body{
  margin: 0;
  padding: 0;
  background-color: #f3f3f3;
}
</style>
