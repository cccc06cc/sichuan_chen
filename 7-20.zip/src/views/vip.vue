<template>
	<div class="vip">
		<div class="v_top">
			<span>
				<!-- <img src="../assets/images/xx.png" alt=""> -->
			</span>
			<p>vip会员</p>
		</div>
		
		<div class="v_card">
			<div class=" _gold">
				<div class="_ka">
					<h2>年卡99.9元</h2>
					<p>自动砍价&nbsp;&nbsp;|&nbsp;&nbsp;送90砍价券</p>
				</div>
			</div>
			<div class="_card_ _silver">
				<div class="_ka">
					<h2>季卡49.9元</h2>
					<p>自动砍价&nbsp;&nbsp;|&nbsp;&nbsp;送30砍价券</p>
				</div>
			</div>
			<div class=" _copper">
				<div class="_ka">
					<h2>年卡19.9元</h2>
					<p>自动砍价&nbsp;&nbsp;|&nbsp;&nbsp;送3砍价券</p>
				</div>
			</div>
		</div>
		<div class="bon">
			<div class="_bon_on">
				支付
			</div>
		</div>
	</div>
</template>

<script>

export default {
  mounted(){
     (function flexible(window, document) {
  var docEl = document.documentElement || document.body;
  var dpr = window.devicePixelRatio || 1;

  function setBodyFontSize() {
    if (document.body) {
    } else {
      document.addEventListener("DOMContentLoaded", setBodyFontSize);
    }
  }
  setBodyFontSize();

  // set 1rem = viewWidth / 10
  function setRemUnit() {
    var rem = docEl.clientWidth / 7.5;
    docEl.style.fontSize = rem + "px";
  }

  setRemUnit();

  // reset rem unit on page resize
  window.addEventListener("resize", setRemUnit);
  window.addEventListener("pageshow", function(e) {
    if (e.persisted) {
      setRemUnit();
    }
  });

  // detect 0.5px supports
  if (dpr >= 2) {
    var fakeBody = document.createElement("body");
    var testElement = document.createElement("div");
    testElement.style.border = ".5px solid transparent";
    fakeBody.appendChild(testElement);
    docEl.appendChild(fakeBody);
    if (testElement.offsetHeight === 1) {
      docEl.classList.add("hairlines");
    }
    docEl.removeChild(fakeBody);
  }

    if (typeof WeixinJSBridge == "object" && typeof WeixinJSBridge.invoke == "function") {
        handleFontSize();
    } else {
        if (document.addEventListener) {
            document.addEventListener("WeixinJSBridgeReady", handleFontSize, false);
        } else if (document.attachEvent) {
            document.attachEvent("WeixinJSBridgeReady", handleFontSize);
            document.attachEvent("onWeixinJSBridgeReady", handleFontSize);
        }
    }
    function handleFontSize() {
        // 设置网页字体为默认大小
        WeixinJSBridge.invoke('setFontSizeCallback', { 'fontSize' : 0 });
        // 重写设置网页字体大小的事件
        WeixinJSBridge.on('menu:setfont', function() {
            WeixinJSBridge.invoke('setFontSizeCallback', { 'fontSize' : 0 });
        });
    }

})(window, document);
  }
}
</script>
<style scoped lang="less">
.vip{
	.v_top{
		display: flex;
		align-items: center;
		padding:0.2rem 0 0.2rem 0.2rem;
		background-color: #fff;
		span{
			width: 0.22rem;
			height: 0.22rem;
			background: url(../assets/images/xx.png) no-repeat;
			background-size: contain;
		}
		p{
			flex: 1;
			text-align: center;
			font-size: 0.34rem;
			font-family: Adobe Heiti Std;
			font-weight: normal;
			color: #000000;
		}
	}
	.v_card{
		padding: 0.33rem 0.26rem 0 0.32rem;
		margin-bottom: 1.68rem!important;
		._card_{
			width: 6.92rem;
			height: 2.72rem;
			background: url(../assets/images/contour.png) no-repeat;
			background-size: contain;
		}
		._gold,._silver,._copper{
			display: flex;
			justify-content: center;
			align-items: center;
			margin-bottom: 0.06rem;
			._ka{
				width:6.6rem;
				height:2.4rem;
				position: relative;
				h2{
					font-size: 0.3rem;
					position: absolute;
					top: 0.9rem;
					left: 2.2rem;
				}
				p{
					font-size: 0.32rem;
					position: absolute;
					left: 0.5rem;
					bottom: 0.2rem;
					font-weight: 500;
				}
			}
		}
		._gold{
			._ka{
				background: url(../assets/images/vip1.png) no-repeat;
				background-size: contain;
				color: #bc4200;
			}
		}
		._silver{
			._ka{
				background: url(../assets/images/vip2.png) no-repeat;
				background-size: contain;
				color: #626262;
			}
		}
		._copper{
			._ka{
				background: url(../assets/images/vip3.png) no-repeat;
				background-size: contain;
				color: #815138;
			}
		}
	}
	.bon{
		padding: 0 0.45rem;
		._bon_on{
			width:6.6rem;
			height: 0.86rem;
			background: linear-gradient(-90deg, #FF4E18, #F20101);
			border-radius: 0.6rem;
			font-size: 0.33rem;
			font-family: Source Han Sans CN;
			font-weight: bold;
			color: #FEFEFE;
			text-align: center;
			line-height: 0.86rem;
		}
	}
}
// *******************************公共样式*********************************
article,aside,blockquote,body,button,code,dd,div,dl,dt,fieldset,figcaption,figure,footer,form,h1,h2,h3,h4,h5,h6,header,hgroup,input,legend,li,menu,nav,ol,p,pre,section,td,textarea,th,ul {
    margin: 0!important;
    padding: 0;
    box-sizing: border-box;
  }
  /****************************************************/
  /******************** html和body ********************/
  /****************************************************/
  html{
    height: 100%;
    line-height: 1.15;
    /*在IOS中阻止文本大小根据设备方向进行大小的调整（需设置meta viewport），仅iOS Safari支持*/
    -webkit-text-size-adjust: 100%;
    background-color: #fff;
  }
  body {
    min-height: 100%;
    width: 100%;
    /* margin: 0 auto!important; */
    background-color: #fff;
    font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", Arial, sans-serif;
    font-weight: 400;
    font-size: 14px;
    color: #333;
    -webkit-font-smoothing: antialiased;
    /*禁止用户选择文本：IE6-9使用私有标签属性onselectstart="return false",Opera12.5使用私有标签属性 unselectable="on"*/
    -webkit-user-select: none;
    /*当用户点击iOS的Safari浏览器中的链接或JavaScript的可点击的元素时，覆盖显示的高亮颜色。*/
    -webkit-tap-highlight-color: transparent;
    -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
  }
  /****************************************************/
  /*********************** 表单 ***********************/
  /****************************************************/
  button,input,select,optgroup,option,textarea {
    border: 0;
    outline: 0;
    background: none;
    /*去掉默认的UI来渲染按钮，仅支持Safari、Chrome和Firefox*/
    -webkit-appearance: none;
    -moz-appearance: none;
    /* 去掉对text-transform的继承（in Edge, Firefox, and IE） */
    text-transform: none;
    /*表单输入文本默认不能继承body的字体，按如下设置可以使用父级字体*/
    font-family: inherit;
    font-size: inherit;
    font-style: inherit;
    font-weight: inherit;
  }
  ::-moz-focus-inner {
    /*解决outline:0时，火狐下仍有边框的问题*/
    border: 0;
    padding: 0;
  }
  :focus {
    outline: 0;
    -webkit-tap-highlight-color: transparent;
  }
  ::-webkit-input-placeholder {
    color: #bbb;
    font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", Arial, sans-serif;
  }
  input:focus,
  textarea:focus,
  keygen:focus,
  select:focus {
    outline-offset: 0;
  }
  select,input {
    vertical-align: middle;
  }
  input[type="search"],
  input[type="search"]::-webkit-search-cancel-button,
  input[type="search"]::-webkit-search-decoration {
    -webkit-appearance: none !important;
  }
  /****************************************************/
  /******************** 表格和列表**********************/
  /****************************************************/
  table {
    border-collapse: collapse;
    border-spacing: 0;
  }
  caption,th {
    text-align: left;
  }
  li {
    list-style: none;
  }
  /****************************************************/
  /******************* 文本和超链接 ********************/
  /****************************************************/
  a,img{
    /*禁用a链接系统默认菜单，iOS 2.0及更高版本的Safari浏览器可用*/
    -webkit-touch-callout: none;
  }
  a,ins {
    text-decoration: none;
  }
  fieldset,img {
    border: 0;
  }
  img {
    vertical-align: middle;
  }
  del {
    text-decoration: line-through;
  }
  b,strong{
    font-weight: normal;
  }
  em,i {
    font-style: normal;
  }
  a {
    color: #333;
  }
  a:focus,
  a:hover {
    color: #66b1ff;
  }
  a:active {
    color: #3a8ee6;
  }
  /****************************************************/
  /******************* 公共样式和类 ********************/
  /****************************************************/
  .clearfix:after {
    content: "";
    display: block;
    line-height: 0;
    visibility: hidden;
    height: 0;
    clear: both;
  }
</style>
