let go_home = document.getElementById('go_home');
go_home.addEventListener('click', function() {
    location.href = "./index.html";
})