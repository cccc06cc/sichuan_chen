let but = document.querySelectorAll(".but ul li button");
for (let i = 0; i < but.length; i++) {
    but[i].addEventListener("click", function() {
        for (let j = 0; j < but.length; j++) {
            but[j].classList.remove("pitch");
        }
        this.classList.add("pitch");
    });
}