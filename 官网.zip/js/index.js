let ul = document.querySelectorAll(".el-menu--horizontal .el-menu");
let that = this;
for (let i = 0; i < ul.length; i++) {
    // ul[i].style.backgroundColor = "#cae1f8";
    ul[i].style.backgroundColor = "";
    ul[i].style.opacity = "0.6";
    ul[i].style.padding = '0 10px'
        // ul[i].style.backgroundColor = "rgba(255,255,255,0.5)";
}

var elevideo = document.getElementById("video");
elevideo.addEventListener('pause', function() {
    // that.control = true;
    console.log(1);
});
elevideo.addEventListener('play', function() {
    // that.control = false;
    console.log(2);
});


let kh_anli_form = document.querySelectorAll(".index_customer_case ._customer_case .right_option ._content form");
let kh_anli_dl = document.querySelectorAll(".index_customer_case ._customer_case .right_option ._content dl");
let kh_anli_dl_dt = document.querySelectorAll(".index_customer_case ._customer_case .right_option ._content dl dt");
let kh_anli_dl_p = document.querySelectorAll(".index_customer_case ._customer_case .right_option ._content dl p");
kh_anli_dl[0].style.backgroundColor = "#e8eefa";
kh_anli_dl_dt[0].style.border = "4px solid #1c5Ad4";
kh_anli_dl_p[0].style.color = "#1c5AD4";
for (let i = 0; i < kh_anli_form.length; i++) {
    kh_anli_form[i].addEventListener("click", function() {
        for (let j = 0; j < kh_anli_form.length; j++) {
            kh_anli_dl[j].style.backgroundColor = "#ffffff";
            kh_anli_dl_p[j].style.color = "#333333";
            kh_anli_dl_dt[j].style.border = "0";
        }
        this.querySelector("dl").style.backgroundColor = "#e8eefa";
        this.querySelector("dl dd p").style.color = "#1c5AD4";
        this.querySelector("dl dt").style.border = "4px solid #1C5AD4";
    })
}

let switch_to = document.querySelectorAll("._switch_to ul li");
for (let i = 0; i < switch_to.length; i++) {
    switch_to[i].addEventListener("click", function() {
        for (let j = 0; j < switch_to.length; j++) {
            switch_to[j].classList.remove("_active");
        }
        this.classList.add("_active");
    }); //测绘设备切换按钮
}
$(".index_customer_case ._customer_case .right_option .top_biaoti button").on('click', function() {
    $(".index_customer_case ._customer_case .right_option .top_biaoti button").removeClass('button_back_color');
    $(this).addClass('button_back_color');
})


// $('#but_content').on("scroll", function() {
//     console.log($(this).scrollTop());
// })

let but_down = document.querySelector("#but_down");
let but_top = document.querySelector("#but_top");
let but_sum = document.querySelectorAll("#but_content form").length;
but_down.addEventListener('click', function() {
    document.querySelector("#but_content").scrollTop = 150 * but_sum;
});
but_top.addEventListener("click", function() {
    document.querySelector("#but_content").scrollTop = 0;
})