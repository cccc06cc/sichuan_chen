import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
// import BScroll from '@better-scroll/core'

// import BScroll from '@better-scroll/core'
// let wrapper = document.querySelector('.wrapper')
// let scroll = new BScroll(wrapper)

// 注册插件
// BScroll.use(Pullup)

// let bs = new BScroll('.wrapper', {
//   probeType: 3,
//   pullUpLoad: true
// })

// import "./assets/css/base.css"
// import "./assets/js/flexible"



import MyVant from "./components/vant/index.js";
// use函数会默认去调用install方法
Vue.use(MyVant);

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
