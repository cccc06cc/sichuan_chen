<template>
	<div id="app">
		<!-- 根路由的出口 -->
		<router-view />
	</div>
</template>
<script>
</script>
<style>

</style>

