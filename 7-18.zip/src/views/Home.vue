<template>
    <div class="home_page">
		<div class="top_home">
			<span></span>
			<p>首页</p>
			<span class="sp_rig"></span>
		</div>
		<div class="search">
			<div class="ipt_left">搜索产品名称</div>
			<div class="service_right"></div>
		</div>
		<div class="slideshow">
			<van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
				<van-swipe-item>
					<img src="../assets/images/ban.png" alt="">
				</van-swipe-item>
				<van-swipe-item>
					<img src="../assets/images/ban.png" alt="">
				</van-swipe-item>
				<van-swipe-item>
					<img src="../assets/images/ban.png" alt="">
				</van-swipe-item>
				<van-swipe-item>
					<img src="../assets/images/ban.png" alt="">
				</van-swipe-item>
			</van-swipe>
		</div>
		<div class="announcement">
			<h2>公告</h2>
			<p>公告用户开单情况及用户注册</p>
		</div>
		<div class="feature">
			<div class="feature_one">
				<p>我们是一家金融综合服务平台</p>
				<div class="understand">了解即融e</div>
			</div>
			<div class="feature_two">
				<ul>
					<li>
						<span><img src="../assets/images/feature_li1.png" alt=""></span>
						<p>特色一</p>
					</li>
					<li>
						<span><img src="../assets/images/feature_li2.png" alt=""></span>
						<p>特色二</p>
					</li>
					<li>
						<span><img src="../assets/images/feature_li3.png" alt=""></span>
						<p>特色三</p>
					</li>
				</ul>
			</div>
		</div>
		<div class="banner">
			<img src="../assets/images/banner.png" alt="">
		</div>
		<div class="credit_card">
			<div class="_card_top">
				<h3>精选信用卡</h3>
				<span></span>
			</div>
			<div class="_card_bot">
				<div class="_card_bot_left">
					<p>办理招行信用卡</p>
					<p>额度最高五万元</p>
				</div>
				<div class="_card_bot_right">
					<div class="_bot_right_one">
						<p>富途送好礼</p>
						<p>1000美元股票卡</p>
					</div>
					<div class="_bot_right_two">
						<p>2万元健康金</p>
						<p>开启健康保障</p>
					</div>
				</div>
			</div>
		</div>
		<div class="popular_product">
			<div class="_product_top">
				<h3>热门融资产品</h3>
				<span></span>
			</div>
			<div class="_product_bot">
				<div class="horizontal-container">
					<div class="scroll-wrapper" ref="scroll">
						<ul class="scroll-content">
							<li class="scroll-item" v-for="(item, index) in shuju" :key="index">
								 <div class="hui">{{item.hui}}</div>
								<div class="ed">
									<h4>{{item.price}}万</h4>
									<p>最高额度({{item.sum}}元)</p>
								</div>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="college">
			<div class="college_top">
				<h3>融资商学院</h3>
				<span></span>
			</div>
			<div class="college_bot">
				<ul>
					<li>
						<p>信用卡</p>
						<p>信用卡进件需知…</p>
					</li>
					<li>
						<p>个人贷款</p>
						<p>个人贷款十条注…</p>
					</li>
					<li>
						<p>小微企业</p>
						<p>企业融资的</p>
					</li>
				</ul>
			</div>
		</div>
		<div class="lie">
			<div class="cont">
				<div class="cont_left">
					<h4>坚持理财会发生什么</h4>
					<p>朋友圈里的小惊喜</p>
				</div>
				<span>
					<img src="../assets/images/lie.png" alt="">
				</span>
			</div>
			<div class="cont">
				<div class="cont_left">
					<h4>坚持理财会发生什么</h4>
					<p>朋友圈里的小惊喜</p>
				</div>
				<span>
					<img src="../assets/images/lie.png" alt="">
				</span>
			</div>
			<div class="cont">
				<div class="cont_left">
					<h4>坚持理财会发生什么</h4>
					<p>朋友圈里的小惊喜</p>
				</div>
				<span>
					<img src="../assets/images/lie.png" alt="">
				</span>
			</div>
		</div>
    </div>
</template>
<script type="text/ecmascript-6">
 import BScroll from '@better-scroll/core'
export default {
    data() {
        return {
            shuju:[{hui:'慧到账',price:100,sum:1},
			{hui:'慧到账',price:100,sum:1},
			{hui:'慧到账',price:100,sum:1},
			{hui:'慧到账',price:100,sum:1},
			{hui:'慧到账',price:100,sum:1},
			{hui:'慧到账',price:100,sum:1},
			{hui:'慧到账',price:100,sum:1},]
        }
    },
    methods: {
		init() {
        this.bs = new BScroll(this.$refs.scroll, {
          scrollX: true,
          probeType: 3,
		  click:true,
		  disableTouch: false
        })
      }
    
	},
	
    computed: {
          
        },
		beforeDestroy() {
      this.bs.destroy()
    },
    mounted(){
		this.init();

       (function flexible(window, document) {
  var docEl = document.documentElement || document.body;
  var dpr = window.devicePixelRatio || 1;

  // adjust body font size
  function setBodyFontSize() {
    if (document.body) {
    } else {
      document.addEventListener("DOMContentLoaded", setBodyFontSize);
    }
  }
  setBodyFontSize();

  // set 1rem = viewWidth / 10
  function setRemUnit() {
    var rem = docEl.clientWidth / 7.5;
    docEl.style.fontSize = rem + "px";
  }

  setRemUnit();

  // reset rem unit on page resize
  window.addEventListener("resize", setRemUnit);
  window.addEventListener("pageshow", function(e) {
    if (e.persisted) {
      setRemUnit();
    }
  });

  // detect 0.5px supports
  if (dpr >= 2) {
    var fakeBody = document.createElement("body");
    var testElement = document.createElement("div");
    testElement.style.border = ".5px solid transparent";
    fakeBody.appendChild(testElement);
    docEl.appendChild(fakeBody);
    if (testElement.offsetHeight === 1) {
      docEl.classList.add("hairlines");
    }
    docEl.removeChild(fakeBody);
  }

    if (typeof WeixinJSBridge == "object" && typeof WeixinJSBridge.invoke == "function") {
        handleFontSize();
    } else {
        if (document.addEventListener) {
            document.addEventListener("WeixinJSBridgeReady", handleFontSize, false);
        } else if (document.attachEvent) {
            document.attachEvent("WeixinJSBridgeReady", handleFontSize);
            document.attachEvent("onWeixinJSBridgeReady", handleFontSize);
        }
    }
    function handleFontSize() {
        // 设置网页字体为默认大小
        WeixinJSBridge.invoke('setFontSizeCallback', { 'fontSize' : 0 });
        // 重写设置网页字体大小的事件
        WeixinJSBridge.on('menu:setfont', function() {
            WeixinJSBridge.invoke('setFontSizeCallback', { 'fontSize' : 0 });
        });
    }

})(window, document);

            }
        //**************************************************************** */
}
</script>
<style scoped lang="less">
.home_page{
	.top_home{
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 0.2rem 0.4rem;
		border-bottom: 1px solid #e7e7e7;
		span:nth-child(1){
			width: 0.28rem;
			height: 0.28rem;
			background: url(../assets/images/top_home1.png) no-repeat;
			background-size: contain;
		}
		p{
			text-align: center;
			font-size: 0.36rem;
			font-family: PingFangSC-Regular, PingFang SC;
			font-weight: 400;
			color: #171717;
			flex: 1;
		}
		.sp_rig{
			width: 0.36rem;
			height: 0.08rem;
			background: url(../assets/images/top_home2.png) no-repeat;
			background-size: contain;
			color: red;
		}
	}
	.search{
		padding: 0 0.32rem;
		display: flex;
		align-items: center;
		margin: 0.24rem 0;
		.ipt_left{
			flex: 1;
			height: 0.6rem;
			background-color: #F5F6FA;
			border-radius: 0.3rem;
			font-size: 0.24rem;
			font-family: PingFangSC-Regular, PingFang SC;
			font-weight: 400;
			color: #80839A;
			line-height: 0.6rem;
			padding-left: 0.72rem;
			position: relative;
		}
		.service_right{
			width: 0.64rem;
			height: 0.72rem;
			background: url(../assets/images/service_right.png) no-repeat;
			background-size: contain;
			margin-left: 0.26rem;
		}
		.ipt_left::before{
			content: "";
			width: 0.24rem;
			height: 0.24rem;
			display: block;
			position: absolute;
			left: 0.32rem;
			top: 0.18rem;
			background: url(../assets/images/ipt_left.png) no-repeat;
			background-size: contain;
		}
	}
	.slideshow{
		padding: 0 0.32rem;
		height: 2.2rem;
		width: 6.86rem;
		.my-swipe{
			width: 6.86rem;
			border-radius: 0.2rem;
			overflow: hidden;
			.van-swipe-item{
				height: 2.2rem;
				width: 6.86rem;
				img{
					width: 100%;
					height: 100%;
				}
			}
		}
	}
	.announcement{
		display: flex;
		padding-left: 0.48rem;
		align-items: center;
		margin: 0.28rem 0;
		h2{
			font-size: 0.36rem;
			font-weight: 800;
			margin-right: 0.2rem;
		}
		p{
			font-size: 0.24rem;
			font-family: PingFangSC-Regular, PingFang SC;
			font-weight: 500;
			color: #494949;
		}
	}
	.feature{
		margin: 0 0.32rem;
		background-color: #fff;
		box-shadow: 0px 2px 8px 6px rgba(0, 0, 0, 0.04);
		border-radius: 0.12rem;
		padding-top: 0.12rem;

		.feature_one{
			width: 6.66rem;
			height: 0.96rem;
			background: url(../assets/images/feature.png) no-repeat;
			background-size: contain;
			margin: 0 0.1rem 0.32rem 0.1rem;
			padding:0.12rem 0.24rem 0;
			display: flex;
			align-items: center;
			justify-content: space-between;
			p{
				font-size: 0.26rem;
				font-family: PingFangSC-Regular, PingFang SC;
				font-weight: 400;
				color: #B07531;
			}
			.understand{
				font-size: 0.24rem;
				font-family: PingFangSC-Regular, PingFang SC;
				font-weight: 400;
				color: #FFFFFF;
				width: 1.6rem;
				height: 0.52rem;
				border-radius: 0.28rem;
				border: 1px solid #FFFFFF;
				text-align: center;
				line-height: 0.52rem;
			}
		}
		.feature_two{
			padding-bottom: 0.32rem;
			ul{
				display: flex;
				li{
					display: flex;
					flex-direction: column;
					align-items: center;
					flex: 1;
					span{
						width: 1.08rem;
						height: 1.08rem;
						border-radius: 50%;
						margin: 0 auto;
						img{
							width: 100%;
							height: 100%;
						}
					}
					p{
						font-size: 0.28rem;
						font-family: PingFangSC-Regular, PingFang SC;
						font-weight: 400;
						color: #333333;
						text-align: center;
						margin-top: 0.18rem;
					}
				}
			}
		}
	}
	.banner{
		margin: 0.32rem 0.32rem 0.44rem 0.32rem;
		height: 2rem;
		border-radius: 0.1rem;
		img{
			width: 100%;
			height: 100%;
		}
	}
	.credit_card{
		margin: 0 0.32rem;
		._card_top{
			display: flex;
			justify-content: space-between;
			align-items: center;
			h3{
				font-size: 0.36rem;
				font-family: PingFangSC-Medium, PingFang SC;
				font-weight: 500;
				color: #333333;
			}
			span{
				width: 0.16rem;
				height: 0.28rem;
				background: url(../assets/images/credit_cardfanhui.png) no-repeat;
				background-size: contain;
			}
		}
		._card_bot{
			display: flex;
			justify-content: space-between;
			._card_bot_left{
				width: 3.36rem;
				height: 2.9rem;
				background: url(../assets/images/credit_card1.png) no-repeat;
				background-size: contain;
				padding:0.24rem 0 0 0.28rem;
				p:first-child{
					font-size: 0.3rem;
					font-family: PingFangSC-Medium, PingFang SC;
					font-weight: 500;
					color: #C56657;
				}
				p:last-child{
					font-size: 0.24rem;
					font-family: PingFangSC-Regular, PingFang SC;
					font-weight: 400;
					color: #CB7568;
				}
			}
			._card_bot_right{
				width: 3.36rem;
				._bot_right_one{
					width: 3.36rem;
					height: 1.38rem;
					background: url(../assets/images/credit_card2.png) no-repeat;
					background-size: contain;
					padding:0.24rem 0 0 0.28rem;
					p:first-child{
						font-size: 0.3rem;
						font-family: PingFangSC-Medium, PingFang SC;
						font-weight: 500;
						color: #B07531;
					}
					p:last-child{
						font-size: 0.24rem;
						font-family: PingFangSC-Regular, PingFang SC;
						font-weight: 400;
						color: #B07531;
					}
				}
				._bot_right_two{
					width: 3.36rem;
					height: 1.38rem;
					background: url(../assets/images/credit_card3.png) no-repeat;
					background-size: contain;
					margin-top: 0.16rem;
					padding:0.24rem 0 0 0.28rem;
					p:first-child{
						font-size: 0.3rem;
						font-family: PingFangSC-Medium, PingFang SC;
						font-weight: 500;
						color: #5D75AF;
					}
					p:last-child{
						font-size: 0.24rem;
						font-family: PingFangSC-Regular, PingFang SC;
						font-weight: 400;
						color: #8293C1;
					}
				}
			}
		}
	}
	.popular_product{
		margin-top: 0.44rem;
		padding: 0 0.32rem;
		._product_top{
			display:flex;
			justify-content: space-between;
			align-items: center;
			h3{
				font-size: 0.36rem;
				font-family: PingFangSC-Medium, PingFang SC;
				font-weight: 700;
				color: #333333;
			}
			span{
				width:0.16rem;
				height: 0.28rem;
				background: url(../assets/images/credit_cardfanhui.png) no-repeat;
				background-size: contain;
			}
		}
		._product_bot{
			margin-top: 0.32rem;
			.horizontal-container{
				.scroll-wrapper{
					width:100%;
					white-space:nowrap;
					overflow:hidden;
					height:2.08rem;
					position:relative;
				.scroll-content{
					display:inline-block;
					height:2.08rem;
					.scroll-item{
						width: 1.72rem;
						height:2.08rem;
						display:inline-block;
						margin-right:0.16rem;
						.hui{
							height: 0.54rem;
							font-size: 0.24rem;
							font-family: PingFangSC-Medium, PingFang SC;
							font-weight: 500;
							color: #FFFFFF;
							background-color: #FF9A50;
							text-align: center;
							border-top-left-radius: 0.16rem;
							border-top-right-radius: 0.16rem;
							line-height: 0.54rem;
						}
						.ed{
							height: 1.54rem;
							background-color: #fef8f4;
							border-bottom-left-radius: 0.16rem;
							border-bottom-right-radius: 0.16rem;
							text-align: center;
							h4{
								font-size: 0.4rem;
								font-family: PingFangSC-Semibold, PingFang SC;
								font-weight: 700;
								color: #ED6D68;
								 padding: 0.16rem 0 0.08rem;
							}
							p{
								font-size: 0.22rem;
								font-family: PingFangSC-Regular, PingFang SC;
								font-weight: 500;
								color: #333333;
							}
						}
					}
				
				}
				}
			}
		}
	}
	 .college{
		 margin: 0.44rem 0.32rem 0.28rem;
		 .college_top{
			display: flex;
			justify-content: space-between;
			align-items: center;
			 h3{
				font-size: 0.36rem;
				font-family: PingFangSC-Medium, PingFang SC;
				font-weight: 700;
				color: #333333;
			 }
			 span{
				width: 0.16rem;
				height: 0.28rem;
				background: url(../assets/images/credit_cardfanhui.png) no-repeat;
				background-size: contain;
			 }
		 }
		 .college_bot{
			 margin-top: 0.38rem;
			 ul{
				 display: flex;
				 overflow: hidden;
				 li{
					 flex-shrink: 0;
					 width: 2.6rem;
					 height: 1.2rem;
					 margin-right: 0.16rem;
					 border-radius: 0.12rem;
					 padding: 0.2rem 0 0 0.36rem;
					 p:first-child{
						font-size: 0.28rem;
						font-family: PingFangSC-Regular, PingFang SC;
						font-weight: 400;
						color: #826264;
					 }
					 p:last-child{
						font-size: 0.18rem;
					    font-family: PingFangSC-Regular, PingFang SC;
					    font-weight: 400;
					    color: #A5898A;
					 }
				 }
				 li:nth-child(1){
					 background-color: #fae8e6;
				 }
				 li:nth-child(2){
					 background-color: #EDEAFD;
				 }
				 li:nth-child(3){
					 background-color: #EFF4FF;
				 }
			 }
		 }
	 }
	 .lie{
		margin: 0 0.32rem;
		.cont{
			display: flex;
			justify-content: space-between;
			align-items: center;
			border-top: 1px solid #f2f2f2;
			padding-top: 0.34rem;
			margin-bottom: 0.28rem;
			.cont_left{
				h4{
					font-size: 0.34rem;
					font-family: PingFangSC-Medium, PingFang SC;
					font-weight: 700;
					color: #333333;
					margin-bottom: 0.18rem;
				}
				p{
					font-size: 0.26rem;
					font-family: PingFangSC-Regular, PingFang SC;
					font-weight: 400;
					color: #8D8D8D;
				}
			}
			span{
				width: 2rem;
				height: 1.26rem;
				border-radius: 0.1rem;
				overflow: hidden;
				img{
					width: 100%;
					height: 100%;
				}
			}
		}
	 }
	
}


/* ***********************公共样式***************************/
/****************************************************/
/********************** 外边距 **********************/
/****************************************************/
article,aside,blockquote,body,button,code,dd,div,dl,dt,fieldset,figcaption,figure,footer,form,h1,h2,h3,h4,h5,h6,header,hgroup,input,legend,li,menu,nav,ol,p,pre,section,td,textarea,th,ul {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  /****************************************************/
  /******************** html和body ********************/
  /****************************************************/
  html{
    height: 100%;
    line-height: 1.15;
    /*在IOS中阻止文本大小根据设备方向进行大小的调整（需设置meta viewport），仅iOS Safari支持*/
    -webkit-text-size-adjust: 100%;
    background-color: #fff;
  }
  body {
    min-height: 100%;
    width: 100%;
    /* margin: 0 auto!important; */
    background-color: #fff;
    font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", Arial, sans-serif;
    font-weight: 400;
    font-size: 14px;
    color: #333;
    -webkit-font-smoothing: antialiased;
    /*禁止用户选择文本：IE6-9使用私有标签属性onselectstart="return false",Opera12.5使用私有标签属性 unselectable="on"*/
    -webkit-user-select: none;
    /*当用户点击iOS的Safari浏览器中的链接或JavaScript的可点击的元素时，覆盖显示的高亮颜色。*/
    -webkit-tap-highlight-color: transparent;
    -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
  }
  /****************************************************/
  /*********************** 表单 ***********************/
  /****************************************************/
  button,input,select,optgroup,option,textarea {
    border: 0;
    outline: 0;
    background: none;
    /*去掉默认的UI来渲染按钮，仅支持Safari、Chrome和Firefox*/
    -webkit-appearance: none;
    -moz-appearance: none;
    /* 去掉对text-transform的继承（in Edge, Firefox, and IE） */
    text-transform: none;
    /*表单输入文本默认不能继承body的字体，按如下设置可以使用父级字体*/
    font-family: inherit;
    font-size: inherit;
    font-style: inherit;
    font-weight: inherit;
  }
  ::-moz-focus-inner {
    /*解决outline:0时，火狐下仍有边框的问题*/
    border: 0;
    padding: 0;
  }
  :focus {
    outline: 0;
    -webkit-tap-highlight-color: transparent;
  }
  ::-webkit-input-placeholder {
    color: #bbb;
    font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", Arial, sans-serif;
  }
  input:focus,
  textarea:focus,
  keygen:focus,
  select:focus {
    outline-offset: 0;
  }
  select,input {
    vertical-align: middle;
  }
  input[type="search"],
  input[type="search"]::-webkit-search-cancel-button,
  input[type="search"]::-webkit-search-decoration {
    -webkit-appearance: none !important;
  }
  /****************************************************/
  /******************** 表格和列表**********************/
  /****************************************************/
  table {
    border-collapse: collapse;
    border-spacing: 0;
  }
  caption,th {
    text-align: left;
  }
  li {
    list-style: none;
  }
  /****************************************************/
  /******************* 文本和超链接 ********************/
  /****************************************************/
  a,img{
    /*禁用a链接系统默认菜单，iOS 2.0及更高版本的Safari浏览器可用*/
    -webkit-touch-callout: none;
  }
  a,ins {
    text-decoration: none;
  }
  fieldset,img {
    border: 0;
  }
  img {
    vertical-align: middle;
  }
  del {
    text-decoration: line-through;
  }
  b,strong{
    font-weight: normal;
  }
  em,i {
    font-style: normal;
  }
  a {
    color: #333;
  }
  a:focus,
  a:hover {
    color: #66b1ff;
  }
  a:active {
    color: #3a8ee6;
  }
  /****************************************************/
  /******************* 公共样式和类 ********************/
  /****************************************************/
  .clearfix:after {
    content: "";
    display: block;
    line-height: 0;
    visibility: hidden;
    height: 0;
    clear: both;
  }
    
</style>