<template>
    <div class="com_head">
        <div class="_head_child">
            <img src="../../assets/images/logo.png" alt="">
            <span><img src="../../assets/images/xyzj.png" alt=""></span>
        </div>  
    </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
    .com_head{
        max-width: 7.5rem;
        height: 3.64rem;
        background: url(../../assets/images/bg.png@2x.png) no-repeat;
        background-size: contain;
        padding: 0.42rem 0 0 0.32rem;
        ._head_child{
            display: flex;
            align-items: center;
            img{
                width: 0.28rem;
                height: 0.28rem;
            }
            span{
                width: 1.5rem;
                height: 0.33rem;
                display: flex;
                align-items: center;
                margin: 0 0.1rem;
                img{
                    width: 100%;
                    height: 100%;
                }
            }
            span::after{
                content:"";
                display:block;
                border:0.12rem solid;
                border-color:transparent transparent transparent #fff;
                margin-left: 0.1rem;
            }
        }
    }
</style>

