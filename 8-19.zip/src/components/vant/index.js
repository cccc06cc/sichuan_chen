// 引入vant组件
// 全部引入
// import { Button,Popup } from 'vant';
// 按需引入
import Button from "vant/lib/button";
import Popup from "vant/lib/popup";
import NavBar from "vant/lib/nav-bar";
import Tabbar from "vant/lib/tabbar";
import TabbarItem from "vant/lib/tabbar-item";
import Icon from "vant/lib/icon";
import Swipe from "vant/lib/swipe";
import SwipeItem from "vant/lib/swipe-item";
import Tab from "vant/lib/tab";
import Tabs from "vant/lib/tabs";
import Uploader from "vant/lib/uploader"


// 引入vant组件的样式
import 'vant/lib/button/style';
import 'vant/lib/popup/style';
import 'vant/lib/nav-bar/style';
import 'vant/lib/tabbar/style';
import 'vant/lib/tabbar-item/style';
import 'vant/lib/icon/style';
import 'vant/lib/swipe/style';
import 'vant/lib/swipe-item/style';
import 'vant/lib/tab/style';
import 'vant/lib/tabs/style';
import 'vant/lib/uploader/style'

// 把引入的vant组件注册成全局组件
// Vue.component(Button.name,Button);
// Vue.component(Popup.name,Popup);


export default {
    install(Vue) {
        Vue.use(Button);
        Vue.use(Popup);
        Vue.use(NavBar);
        Vue.use(Tabbar);
        Vue.use(TabbarItem);
        Vue.use(Icon);
        Vue.use(Swipe);
        Vue.use(SwipeItem);
        Vue.use(Tab);
        Vue.use(Tabs);
        Vue.use(Uploader);
    }
}