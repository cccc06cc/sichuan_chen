<template>
    <div class="layout">
        <!-- 头部 -->
		<van-nav-bar
            fixed
			:title="tit"
			@click-left="onClickLeft"
			@click-right="onClickRight"
            v-if="header"
		>
            <template slot="left">
                <!-- <slot name="licon"></slot> -->
                <van-icon slot="licon" color="#333" size="0.3rem" name="cross"/>
            </template>
             <template slot="right">
                <!-- <slot name="ricon"></slot> -->
                <van-icon slot="ricon" color="#333" size="0.36rem" name="ellipsis"/>
            </template>
        </van-nav-bar>
        <div class="main">
            <!-- 匿名插槽 -->
            <slot></slot>
        </div>
        <!-- 底部 -->
        <!-- route:开启路由功能 -->
		<van-tabbar route v-model="active" v-if="footer">
            <!--  -->
			<van-tabbar-item
                v-for="(item,index) in footer_list"
                :key="index"
                @click="click_nav(item)"
            >
            <span :style="( (item.url === $route.path) || ( $route.path.indexOf(item.keyword) != -1 )  ) ? 'color:#1f5af4' : 'color:#b8b8d2'">{{ item.name }}</span>
           <template #icon="props">
              <img :src=" ( (item.url === $route.path) || ( $route.path.indexOf(item.keyword) != -1 )  ) ? item.img1 : item.img2 " />
            </template>
            </van-tabbar-item>
		</van-tabbar>
    </div>
</template>

<script>
export default {
    props:{
        tit:{
            type:String,
            default:"信用专家"
        },
        footer:{
            type:Boolean,
            default: true
        },
        header:{
            type:Boolean,
            default:true
        }
    },
    data(){
		return {
			active:0,
            footer_list:[
                {
                    name:"首页",
                    img1:require("../../assets/images/w1.png"),
                    img2:require("../../assets/images/x1.png"),
                    url:"/",
                },
                 {
                    name:"热点新闻",
                    img1:require("../../assets/images/w2.png"),
                    img2:require("../../assets/images/x2.png"),
                    url:"/hotnews",
                } ,{
                    name:"订单",
                    img1:require("../../assets/images/w3.png"),
                    img2:require("../../assets/images/x3.png"),
                    url:"/order",
                }
                 ,{
                    name:"推荐中心",
                    img1:require("../../assets/images/w4.png"),
                    img2:require("../../assets/images/x4.png"),
                    url:"/recommend",
                }
                 ,{
                    name:"我的",
                    img1:require("../../assets/images/w5.png"),
                    img2:require("../../assets/images/x5.png"),
                    url:"/my",
                }
            ]
		}
	},
	methods: {
         click_nav(item){
            this.$router.push(item.url)
        },
		onClickLeft() {
            // history是浏览器提供的
            // go 正值代表前进
            // go 负值代表后退
            history.go(-1);
		},
		onClickRight() {
		
		},
	},
}
</script>

<style>
    .van-tabbar,.van-nav-bar{
		max-width: 100vw;
		left: auto !important;
	}
    .main{
        padding-top: 0.92rem;
        padding-bottom: 1rem;
    }
</style>