import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home';
import My from '../views/My';
import hotNews from '../views/Hot_News';
import Order from '../views/Order_Form';
import Recommend from '../views/Recommend';
import orderIssue from "../views/Order_Form/childCmps/order_issue.vue"

Vue.use(VueRouter)

// 路由清单
// 顶级的路由，对应的组件会被加载到根组件的router-view中
// 跟router-link所在的位置没有关系
// 无论在任何页面,只要你要切换的组件时顶级的,就会被插入到根组件的router-view中
const routes = [{
        path: '/',
        component: Home,
    },
    {
        path: '/my',
        component: My
    },
    {
        path: '/hotnews',
        component: hotNews
    },
    {
        path: '/order',
        component: Order
    },
    {
        path: '/recommend',
        component: Recommend
    },
    {
        path: '/order_issue',
        component: orderIssue
    }
]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes
})

export default router