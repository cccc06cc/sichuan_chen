<template>
<div class="hot_news">
	<h1>热点新闻</h1>
  <layout></layout>
</div>
</template>

<script>
import layout from "../../components/layout";
export default {
	components:{
		layout
	}
}
</script>

<style>
	
</style>