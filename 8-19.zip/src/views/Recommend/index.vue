<template>
  <div class="recommend">
    <layout :footer="false">
      <comhead></comhead>
      <!-- 销售奖金 -->
      <div class="sales_bonus">
        <div class="_sales_bonus">
          <!-- 协议 -->
          <div class="agreement">查看协议</div>
          <!-- 信用专家，推广达人 -->
          <div class="generalize">立即成为信用专家推广人</div>
        </div>
      </div>
      <!-- 完成任意订单 -->
      <div class="accomplish_order">
        <div class="_accomplish_order">
          <dl>
            <dt><img src="../../assets/images/dingdan@2x.png" alt=""></dt>
            <dd>
              <h2>完成任意订单</h2>
              <p>即可享受推广人特权</p>
              <button>去下单</button>
            </dd>
          </dl>
          <dl>
            <dt><img src="../../assets/images/zhifu@2x.png" alt=""></dt>
            <dd>
              <h2>完成任意订单</h2>
              <p>即可享受推广人特权</p>
              <button>去下单</button>
            </dd>
          </dl>
        </div>
      </div>
    </layout>
  </div>
</template>

<script>
import layout from "../../components/layout";
import comhead from "../../components/head/index.vue"
export default {
  components: { layout,comhead },
}
</script>

<style lang="less" scoped>
// 销售奖金
.sales_bonus{
  padding: 0 0.28rem;
  margin-top: -2.44rem;
  ._sales_bonus{
    width: 100%;
    height: 4.96rem;
    background: url(../../assets/images/xiaoshou@2x.png) no-repeat;
    background-size: contain;
    position: relative;
    // 协议按钮
    .agreement{
      width: 1.36rem;
      height: 0.58rem;
      background: linear-gradient(90deg, #507FF4 0%, #4C61E1 100%);
      box-shadow: 0px 4px 16px 8px rgba(73,99,227,0.21);
      border-radius: 0.16rem 0px 0px 0.16rem;
      font-size: 0.24rem;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 500;
      color: #FFFFFF;
      text-align: center;
      line-height: 0.58rem;
      position: absolute;
      right: 0;
      top: 0.64rem;
    }
    .generalize{
      width: 3.74rem;
      height: 0.72rem;
      background: linear-gradient(90deg, #507FF4 0%, #4C61E1 100%);
      box-shadow: 0px 4px 16px 8px rgba(24,46,158,0.21);
      border-radius: 0.36rem;
      font-size: 0.3rem;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 500;
      color: #FFFFFF;
      text-align: center;
      line-height: 0.72rem;
      position: absolute;
      left: 1.6rem;
      bottom: 0.34rem;
    }
  }
}
.accomplish_order{
  padding: 0 0.28rem;
  margin-top: 0.24rem;
  ._accomplish_order{
    background-color: #fff;
    padding: 0.32rem 0 0.78rem 0.32rem;
    border-radius: 0.1rem;
    dl:last-child{
      margin-bottom: 0;
    }
    dl{
      display: flex;
      margin-bottom: 0.66rem;
      dt{
        width: 2.16rem;
        height: 2.16rem;
        margin-right: 0.32rem;
        img{
          width: 100%;
          height: 100%;
        }
      }
      dd{
        margin-top: 0.08rem;
        h2{
          font-size: 0.32rem;
          color: #212121;
          font-family: PingFangSC-Medium, PingFang SC;
          font-weight: 700;
        }
        p{
          font-size: 0.26rem;
          color: #447AF5;
          font-family: PingFangSC-Medium, PingFang SC;
          font-weight: 700;
          margin: 0.2rem 0 0.54rem;
        }
        button{
          width: 1.36rem;
          height: 0.5rem;
          background: linear-gradient(90deg, #507FF4 0%, #4C61E1 100%);
          border-radius: 0.3rem;
          text-align: center;
          line-height: 0.5rem;
          font-size: 0.24rem;
          font-family: PingFangSC-Regular, PingFang SC;
          color: #FFFFFF;
        }
      }
    }
  }
}
</style>