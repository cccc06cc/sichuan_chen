<template>
  	<div class="question">
		<layout tit="我的订单">
			<van-tabs
					color="#1f5af4"
					line-width="20"
					title-inactive-color="#999999"
					title-active-color="#171717"
					v-model="active"
					@click="on_click"
					>
				<van-tab title="全部">内容 1</van-tab>
				<van-tab title="评估中">内容 2</van-tab>
				<van-tab title="修复中">内容 3</van-tab>
				<van-tab title="已完成">内容 4</van-tab>
				<van-tab title="已取消">内容 5</van-tab>
			</van-tabs>
			<div class="_order">
				<div class="order">
					<div class="_order_t">
						<p>订单号：12312831293</p>
						<h2>待支付</h2>
					</div>
					<div class="_order_c"
						 @click="order_issue"
					>
						<dl>
							<dt><img src="../../assets/images/order.png" alt=""></dt>
							<dd>
								<div>
									<h3>征信异议申诉</h3>
									<span>¥100</span>
								</div>
								<p>项目类型：个人征信异议申诉</p>
								<p>创建时间：2021-01-14 14:56:00</p>
							</dd>
						</dl>
					</div>
					<div class="_order_b">
						<button>取消支付</button>
						<button>立即支付</button>
					</div>
				</div>
			</div>
		</layout> 
	</div>
</template>

<script>
import layout from "../../components/layout/index.vue";
export default {
  	components:{
        layout
    },
	data(){
		return {
			active:0
		}
	},
	 methods: {
    on_click(name, title) {
		// name:索引，title:内容
      console.log(name,title);

    },
	order_issue(){
		// $route.path('/order_issue');
		// $router('/order_issue');
		this.$router.push('/order_issue')
	}
  }
}
</script>

<style lang="less" scoped>
	.van-tab{
		color: red!important;
	}
	._order{
		padding: 0 0.32rem;
		.order{
			background-color: #fff;
			padding: 0.22rem 0.32rem 0.16rem;
			border-radius: 0.16rem;
			._order_t{
				display: flex;
				align-items: center;
				justify-content: space-between;
				p{
					font-size: .26rem;
					font-family: PingFangSC-Regular, PingFang SC;
					color: #737373;
				}
				h2{
					font-size: .3rem;
					font-family: PingFangSC-Regular, PingFang SC;
					color: #FF0033;
				}
			}
			._order_c{
				margin-top: 0.44rem;
				dl{
					display: flex;
					dt{
						width: 1.6rem;
						height: 1.6rem;
						border-radius: 0.04rem;
                		overflow: hidden;
						img{
							width: 100%;
							height: 100%;
						}
					}
					dd{
						padding: .06rem 0 0 .24rem;
						flex: 1;
						div{
							display: flex;
							align-items: center;
							justify-content: space-between;
							margin-bottom: 0.2rem;
							h3{
								font-size: .32rem;
								font-family: PingFangSC-Medium, PingFang SC;
								color: #333333;
							}
							span{
								font-size: .3rem;
								font-family: PingFangSC-Medium, PingFang SC;
								color: #4949EC;
							}
						}
						p{
							font-size: .24rem;
							font-family: PingFangSC-Regular, PingFang SC;
							color: #989898;
							margin-bottom: 0.12rem;
						}
					}
				}
			}
			._order_b{
				display: flex;
				justify-content: flex-end;
				margin-top: 0.36rem;
				button{
					width: 1.68rem;
					height: 0.6rem;
					font-size: 0.26rem;
					font-family: PingFangSC-Regular, PingFang SC;
					border-radius: 0.29rem;
				}
				button:first-child{
					background-color: #EDF3FF;
					color: #4876EE;
					margin-right: 0.32rem;
				}
				button:last-child{
					background: linear-gradient(180deg, #4F7DF0 0%, #4F60E0 100%);
					color: #ffffff;
				}
			}
		}
	}
</style>

