<template>
  <layout
    :footer="false"
    tit="我的订单"
  >
  <div class="_appeal">
      <div class="appeal">
        <p>订单号：12312831293</p>
        <dl>
			<dt><img src="../../../assets/images/order.png" alt=""></dt>
			<dd>
                <div>
                    <h3>征信异议申诉</h3>
                    <span>¥100</span>
                </div>
                <p>项目类型：个人征信异议申诉</p>
                <p>创建时间：2021-01-14 14:56:00</p>
		    </dd>
	    </dl>
      </div>
  </div>
  <!-- 上传 -->
  <div class="_uploading">
      <div class="uploading">
          <div class="_uploading_but">
              <h2>个人征信报告上传预览</h2>
              <div class="uploading_but">
                  <img src="../../../assets/images/order.png" alt="">
                  <div class="_but">
                      <van-uploader 
                      :after-read="afterRead" 
                      preview-size="1.3rem"
                      />
                      <p>上传图片</p>
                  </div>
              </div>
          </div>
          <div class="rict_text" 
                contenteditable="true"
               @focus="sheng"
               @blur="ming"
               >
              {{shengming}}
          </div>
      </div>
  </div>
  <div class="bottom_service">
      <div class="_service">
          <span>
              <img src="../../../assets/images/kefu@2x.png" alt="">
          </span>
          <p>联系客服</p>
      </div>
      <div class="_button">
          <button>取消支付</button>
		  <button>立即支付</button>
      </div>
  </div>
  </layout>
</template>

<script>
import layout from "../../../components/layout/index.vue";
export default {
    	components:{
        layout
       },
       data(){
           return {
               shengming:"声明文本~"
           }
       },
       methods:{
           afterRead(){
            //    console.log(1);
           },
            sheng(){
                this.shengming="";
            },
            ming(){
                this.shengming="声明文本~";
            }
       }
}
</script>

<style lang="less" scoped>
._appeal{
    padding: 0 0.2rem;
    margin-top: 0.2rem;
    .appeal{
        background-color: #ffffff;
        padding: 0.24rem 0.56rem 0.2rem 0.32rem;
        border-radius: 0.24rem;
        p{
            font-size: 0.26rem;
            font-family: PingFangSC-Regular, PingFang SC;
            color: #737373;
            margin-bottom: 0.44rem;
        }
        dl{
            display: flex;
            dt{
                width: 1.6rem;
                height: 1.6rem;
                border-radius: 0.04rem;
                overflow: hidden;
                img{
                    width: 100%;
                    height: 100%;
                }
            }
            dd{
				padding: .06rem 0 0 .24rem;
				flex: 1;
				div{
					display: flex;
					align-items: center;
					justify-content: space-between;
					margin-bottom: 0.2rem;
					h3{
						font-size: .32rem;
						font-family: PingFangSC-Medium, PingFang SC;
						color: #333333;
					}
					span{
						font-size: .3rem;
						font-family: PingFangSC-Medium, PingFang SC;
						color: #4949EC;
					}
				}
				p{
					font-size: .24rem;
					font-family: PingFangSC-Regular, PingFang SC;
					color: #989898;
					margin-bottom: 0.12rem;
				}
			}
            
        }
    }
}
._uploading{
    padding: 0 0.2rem;
    margin-top: 0.2rem;
    .uploading{
        background-color: #fff;
        border-radius: 0.24rem;
        padding: 0.2rem 0.22rem;
        ._uploading_but{
            h2{
                font-size: 0.32rem;
                font-family: PingFangSC-Medium, PingFang SC;
                color: #171717;
            }
            .uploading_but{
                display: flex;
                margin-top: 0.32rem;
            img{
                width: 1.36rem;
                height: 1.36rem;
                margin-right: 0.32rem;
            }
            ._but{
                width: 1.36rem;
                height: 1.36rem;
                border: 1px dashed #979797;
                position: relative;
            }
            p{
                font-size: 0.2rem;
                font-family: PingFangSC-Regular, PingFang SC;
                color: #999999;
                // color: red;
                position: absolute;
                bottom: 0.1rem;
                left: 0.2rem;
            }
            
            }

        }
        .rict_text{
            padding: 0.3rem;
            margin-top: 0.32rem;
            width: 100%;
            height: 4.26rem;
            background-color: #f6f6f6;
            border-radius: 0.24rem;
            overflow: hidden;
            font-size: 0.28rem;
            font-family: PingFangSC-Regular, PingFang SC;
            font-weight: 400;
            color: #999999;
        }
    }
}
.bottom_service{
    position: fixed;
    left: 0;
    bottom: 0;
    height: 1.08rem;
    width: 100%;
    max-width: 7.5rem;
    background-color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 0.32rem;
    ._service{
        display: flex;
        align-items: center;
        span{
            width: 0.52rem;
            height: 0.52rem;
            margin-right: 0.16rem;
            img{
                width: 100%;
                height: 100%;
            }
        }
        p{
            font-size: 0.28rem;
            font-family: PingFangSC-Medium, PingFang SC;
            color: #4876EE;
        }
    }
    ._button{
        button{
					width: 1.92rem;
					height: 0.68rem;
					font-size: 0.26rem;
					font-family: PingFangSC-Regular, PingFang SC;
					border-radius: 0.34rem;
				}
				button:first-child{
					background-color: #EDF3FF;
					color: #4876EE;
					margin-right: 0.32rem;
				}
				button:last-child{
					background: linear-gradient(180deg, #4F7DF0 0%, #4F60E0 100%);
					color: #ffffff;
				}
    }
}
</style>

