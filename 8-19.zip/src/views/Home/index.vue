<template>
    <div class="home">
        <layout>
            <!-- <van-icon slot="licon" color="#333" name="cross"/>
            <van-icon slot="ricon" color="#333" name="ellipsis"/> -->
          <comhead></comhead>
          <div class="home_banner">
              <div class="_banner">
                  <van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
                    <van-swipe-item><img src="../../assets/images/cs1.png" alt=""></van-swipe-item>
                    <van-swipe-item><img src="../../assets/images/cs2.jpg" alt=""></van-swipe-item>
                    <van-swipe-item><img src="../../assets/images/cs3.jpg" alt=""></van-swipe-item>
                    <van-swipe-item><img src="../../assets/images/cs1.png" alt=""></van-swipe-item>
                  </van-swipe>
              </div>
          </div>
          <div class="home_credit">
              <div class="_credit">
                  <div class="_credit_o">
                      <div>
                          <span><img src="../../assets/images/daiban@2x.png" alt=""></span>
                          <p>您有带支付订单，请点击查看</p>
                      </div>
                      <div class="_concentric">
                          <img src="../../assets/images/txy.png" alt="">
                      </div>
                  </div>
                  <div class="_credit_t">
                      <div class="_credit_t_o">
                          <h2>个人信用</h2>
                          <p>异议申诉</p>
                      </div>
                      <div class="_credit_t_t">
                          <h2>企业信用</h2>
                          <p>问题咨询</p>
                      </div>
                  </div>
              </div>
          </div>
          <div class="faq">
              <div class="_faq">
                  <!-- 常见问题-按钮 -->
                  <div class="_faq_button">
                      常见问题
                  </div>
                  <div class="_faq_user">
                      <!-- 占位 -->
                      <div style="width:100%;height:0.5rem"></div>
                      <!-- -最新参与用户- -->
                      <div class="_new_user">
                          <span></span>
                          <p>最新参与用户</p>
                          <span></span>
                      </div>
                      <!-- 新用户列表 -->
                      <!-- <div class="_user_list">
                        <div class="_new_user_list" 
                            v-for="(item,index) in new_user_list"
                            :key="index"
                            >
                            <span>
                                <img src="" alt="">
                            </span>
                            <p>【{{item.name}}】&nbsp;:&nbsp;{{item.number}}&nbsp;&nbsp;{{item.time}}分钟前</p>
                        </div>
                      </div> -->
                      <div class="_user_list">
                          <van-swipe 
                                    :show-indicators="false"
                                    vertical
                                    style="height=0.44rem"
                                    :autoplay="1000"
                                    >
                              <van-swipe-item
                                            v-for="(item,index) in new_user_list"
                                            :key="index"
                              >
                                  <div class="_new_user_list">
                                      <span>
                                          <img src="" alt="">
                                      </span>
                                      <p>【{{item.name}}】&nbsp;:&nbsp;{{item.number}}&nbsp;&nbsp;{{item.time}}分钟前</p>
                                  </div>
                              </van-swipe-item>
                          </van-swipe>
                      </div>
                      <div class="_user_list">
                          <van-swipe 
                                    :show-indicators="false"
                                    vertical
                                    style="height=0.44rem"
                                    :autoplay="2300"
                                    >
                              <van-swipe-item
                                            v-for="(item,index) in new_user_list"
                                            :key="index"
                              >
                                  <div class="_new_user_list">
                                      <span>
                                          <img src="" alt="">
                                      </span>
                                      <p>【{{item.name}}】&nbsp;:&nbsp;{{item.number}}&nbsp;&nbsp;{{item.time}}分钟前</p>
                                  </div>
                              </van-swipe-item>
                          </van-swipe>
                      </div>
                      <div class="_user_list">
                          <van-swipe 
                                    :show-indicators="false"
                                    vertical
                                    style="height=0.44rem"
                                    :autoplay="3500"
                                    >
                              <van-swipe-item
                                            v-for="(item,index) in new_user_list"
                                            :key="index"
                              >
                                  <div class="_new_user_list">
                                      <span>
                                          <img src="" alt="">
                                      </span>
                                      <p>【{{item.name}}】&nbsp;:&nbsp;{{item.number}}&nbsp;&nbsp;{{item.time}}分钟前</p>
                                  </div>
                              </van-swipe-item>
                          </van-swipe>
                      </div>
                  </div>
              </div>
          </div>
        </layout>
    </div>
</template>

<script>
import layout from "../../components/layout/index.vue";
import comhead from "../../components/head/index.vue";
// import { Swipe, SwipeItem } from 'vant';
export default {
    data(){
        return {
            new_user_list:[
                {
                    name:"赵xx",
                    number:13843814380,
                    time:30
                },
                {
                    name:"赵xx",
                    number:13843814380,
                    time:30
                },
                {
                    name:"赵xx",
                    number:13843814380,
                    time:30
                }
            ]
        }
    },
    components:{
        layout,
        comhead,
    }
}
</script>
<style lang="less" scoped>
.home_banner{
    width: 100%;
    height: 2.8rem;
    padding: 0 0.3rem;
    margin-top: -2.4rem;
    ._banner{
        width: 100%;
        height: 100%;
        // background-color: #FFF;
        .my-swipe{
            width: 100%;
            height: 100%;
            border-radius: 0.2rem;
            .van-swipe-item{
                overflow: hidden;
                width: 100%;
                height: 100%;
                img{
                    width: 100%;
                    height: 100%;
                }
            }
        }
    }
}
.home_credit{
    padding: 0 0.08rem;
    margin-top: 0.1rem;
    ._credit{
        width: 100%;
        height: 3.84rem;
        background: url(../../assets/images/tongzhi-2@2x.png) no-repeat;
        background-size: contain;
        ._credit_o{
            display: flex;
            align-items: center;
            padding-top: 0.64rem;
            justify-content: space-between;
            div:first-child{
                padding: 0 0 0 0.52rem;
                display: flex;
                align-items: center;
                span{
                    margin-top: -0.06rem;
                    width: 0.76rem;
                    height: 0.3rem;
                    margin-right: 0.24rem;
                    img{
                        width: 100%;
                        height: 100%;
                    }
                }
                p{
                    font-size: 0.28rem;
                    font-family: PingFangSC-Medium, PingFang SC;
                    color: #303030;
                }
            }
            ._concentric{
                margin-top: -0.1rem;
                margin-right: 0.56rem;
                width: 0.48rem;
                height: 0.48rem;
                border-radius: 50%;
                box-shadow: 0px 4px 12px 0px rgba(79,126,252,0.23);
                    img{
                        width: 100%;
                        height: 100%;
                }
                
            }
        }
        ._credit_t{
            margin-top: 0.38rem;
            padding: 0 0.36rem;
            display: flex;
            justify-content: space-between;
            ._credit_t_o{
                background: url(../../assets/images/geren@2x.png) no-repeat;
            }
            ._credit_t_t{
                background: url(../../assets/images/qiye@2x.png) no-repeat;
            }
            ._credit_t_o,._credit_t_t{
                width: 3.24rem;
                height: 2rem;
                background-size: contain;
                padding: 0.24rem 0 0 0.28rem;
                h2{
                    font-size: 0.32rem;
                    font-family: PingFangSC-Semibold, PingFang SC;
                    font-weight: 600;
                    color: #27314A;
                    margin-bottom: 0.14rem;
                }
                p{
                    font-size: 0.26rem;
                    font-family: PingFangSC-Medium, PingFang SC;
                    font-weight: 500;
                    color: #8E94A7;
                }
            }
        }
    }
}
.faq{
    padding: 0 0.28rem;
    ._faq{
        padding: 0.16rem 0.16rem 0;
        box-shadow: 0px 2px 20px 0px rgba(194,194,194,0.23);
        border-radius: 0.2rem;
        ._faq_button{
            width: 2.88rem;
            height: 0.76rem;
            background: linear-gradient(180deg, #4F7DF0 0%, #4F60E0 100%);
            border-radius: 0.48rem;
            margin: 0 auto;
            font-size: 0.32rem;
            font-family: PingFangSC-Medium, PingFang SC;
            font-weight: 500;
            color: #FFFFFF;
            line-height: 0.76rem;
            text-align: center;
            position: relative;
        }
        ._faq_user{
            margin-top: -0.5rem;
            width: 100%;
            height: 3.6rem;
            background: linear-gradient(181deg, #DEE8FD 0%, #FFFFFF 100%);
            border-radius: 0.16rem;
            overflow: hidden;
            border: 1px solid #DBE4FF;
            padding-left: 0.32rem;
            ._new_user{
                display: flex;
                align-items: center;
                margin:0.28rem 0 0.28rem 1.74rem;
                p{
                    font-size: 0.24rem;
                    font-family: PingFangSC-Regular, PingFang SC;
                    font-weight: 400;
                    color: #4876EE;
                    margin: 0 0.24rem;
                }
                span{
                    width: 0.76rem;
                    height: 0.01rem;
                    background-color: #C9DBFF;
                }
            }
            // ._user_list{
            //     padding: 0.28rem 0.28rem 0;
            //     display: flex;
            //     flex-direction: column;
            //     // height:.44rem;
            //     ._new_user_list{
            //         display: flex;
            //         align-items: center;
            //         // background-color: #dfe8f8;
            //         background-color: red;
            //         width: 100%;
            //         // height: 0.44rem;
            //         height: 100%;
            //         border-radius: 2rem;
            //         margin-bottom: 0.16rem;
            //         span{
            //             width: 0.36rem;
            //             height: 0.36rem;
            //             background-color: #ccc;
            //             border-radius: 50%;
            //             overflow: hidden;
            //             img{
            //                 width: 100%;
            //                 height: 100%;
            //             }
            //         }
            //         p{
            //             font-size: 0.2rem;
            //             font-family: PingFangSC-Regular, PingFang SC;
            //             font-weight: 700;
            //             color: #4876EE;
            //         }
            //     }
            //     ._new_user_list:last-child{
            //         margin-bottom: 0;
            //     }
            // }
            ._user_list{
                background-color: #dfe8f8;
                margin-bottom: 0.16rem;
                border-radius: 2rem;
                margin-right: 0.28rem;
                .van-swipe{
                    height: 0.44rem;
                    .van-swipe-item{
                        ._new_user_list{
                            display: flex;
                            align-items: center;
                            span{
                                width: 0.36rem;
                                height: 0.36rem;
                                border-radius: 50%;
                                overflow: hidden;
                                img{
                                    width: 100%;
                                    height: 100%;
                                }
                            }
                            p{
                                font-size: 0.2rem;
                                font-family: PingFangSC-Regular, PingFang SC;
                                font-weight: 700;
                                color: #4876EE;
                            }
                        }
                    }
                }
            }
            ._user_list:last-child{
                margin-bottom: 0;
            }
        }
    }
}

</style>
  