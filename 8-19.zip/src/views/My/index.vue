<template>
  	<div class="my">
		<layout>
			<comhead></comhead>
			<div class="user">
				<span><img src="../../assets/images/touxiang@2x.png" alt=""></span>
				<h2>袁某某</h2>
			</div>
			<!-- 我的订单 -->
			<div class="_my_order">
				<div class="my_order">
					<h3>我的订单</h3>
					<ul>
						<li>
							<span style="width:0.42rem;">
								<img src="../../assets/images/xiufuzhong@2x.png" alt="">
							</span>
							<p>修复中</p>
						</li>
						<li>
							<span>
								<img src="../../assets/images/pinggu@2x.png" alt="">
							</span>
							<p>评估中</p>
						</li>
						<li>
							<span style="width:0.38rem">
								<img src="../../assets/images/xiufu-2@2x.png" alt="">
							</span>
							<p>修复中</p>
						</li>
						<li>
							<span style="width:">
								<img src="../../assets/images/wancheng@2x.png" alt="">
							</span>
							<p>已完成</p>
						</li>
						<li>
							<span style="width:">
								<img src="../../assets/images/quxiao@2x.png" alt="">
							</span>
							<p>已取消</p>
						</li>
					</ul>
				</div>
			</div>
			<!-- 个人信息 -->
			<div class="user_collect">
				<ul>
					<li>
						<span style="width:0.3rem">
							<img src="../../assets/images/gerenxinxi@2x.png" alt="">
						</span>
						<p>个人信息</p>
					</li>
					<li>
						<span style="width:0.34rem">
							<img src="../../assets/images/shoucang@2x.png" alt="">
						</span>
						<p>我的收藏</p>
					</li>
				</ul>
			</div>
			<!-- 投诉建议 -->
			<div class="about_us">
				<ul>
					<li>
						<span style="width:0.3rem">
							<img src="../../assets/images/tousu@2x.png" alt="">
						</span>
						<p>投诉建议</p>
					</li>
					<li>
						<span style="width:0.32rem;height:0.32rem">
							<img src="../../assets/images/lianxi@2x.png" alt="">
						</span>
						<p>联系我们</p>
					</li>
					<li>
						<span style="height:0.3rem">
							<img src="../../assets/images/women@2x.png" alt="">
						</span>
						<p>关于我们</p>
					</li>
				</ul>
			</div>
		</layout> 
	</div>
</template>

<script>
import layout from "../../components/layout/index.vue";
import comhead from "../../components/head/index.vue";
export default {
  	components:{
        layout,comhead
    }
}
</script>

<style lang="less" scoped>
.user{
	margin-top: -2.64rem;
	display: flex;
	align-items: center;
	span{
		width:1.36rem;
		height: 1.36rem;
		border-radius: 50%;
		margin: 0 0.32rem 0 0.52rem;
		img{
			width: 100%;
			height: 100%;
		}
	}
	h2{
		font-size: 0.44rem;
		font-family: PingFangSC-Medium, PingFang SC;
		color: #FFFFFF;
	}
}
._my_order{
	margin-top: 0.4rem;
	padding: 0 0.2rem;
	.my_order{
		background-color: #fff;
		border-radius: 0.16rem;
		// box-shadow: 0 0 0.1rem #ccc;
		h3{
			padding-top:0.24rem ;
			margin: 0 0 0 0.32rem;
			font-size: 0.32rem;
			font-family: PingFangSC-Medium, PingFang SC;
			color: #000000;
		}
		ul{
			display: flex;
			padding: 0 0.48rem 0.34rem;
			justify-content: space-between;
			margin-top: 0.32rem;
			li{
				display: flex;
				flex-direction: column;
				align-items: center;
				span{
					width: 0.44rem;
					height: 0.42rem;
					margin-bottom: 0.22rem;
					img{
						width: 100%;
						height: 100%;
					}
				}
				p{
					font-size: 0.24rem;
					font-family: PingFangSC-Regular, PingFang SC;
					color: #000000;
					font-weight: 700;
				}
			}
		}
	}
}
.user_collect{
	padding: 0 0.2rem;
	margin-top: 0.2rem;
	ul{
		background-color: #ffffff;
		border-radius: 0.16rem;
		padding: 0.38rem 0.5rem 0.36rem 0.5rem;
		li:last-child{
			margin-bottom: 0;
			border: 0;
		}
		li{
			display: flex;
			align-items: center;
			margin-bottom: 0.32rem;
			border-bottom: 1px solid #f1f1f1;
			padding-bottom:0.32rem;
			span{
				height: 0.32rem;
				margin-right: 0.32rem;
				img{
					width: 100%;
					height: 100%;
				}
			}
			p{
				font-size: 0.3rem;
				font-family: PingFangSC-Regular, PingFang SC;
				color: #303141;
			}
		}
	}
}
.about_us{
	padding: 0 0.2rem;
	margin-top: 0.2rem;
	ul{
		background-color: #ffffff;
		border-radius: 0.16rem;
		padding: 0.38rem 0.5rem 0.36rem 0.5rem;
		li:last-child{
			margin-bottom: 0;
			border: 0;
		}
		li{
			display: flex;
			align-items: center;
			margin-bottom: 0.32rem;
			border-bottom: 1px solid #f1f1f1;
			padding-bottom:0.32rem;
			span{
				height: 0.34rem;
				margin-right: 0.34rem;
				img{
					width: 100%;
					height: 100%;
				}
			}
			p{
				font-size: 0.3rem;
				font-family: PingFangSC-Regular, PingFang SC;
				color: #303141;
			}
		}
	}
}
</style>