import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

import "./assets/js/flexible"; 
import "./assets/css/base.css"; 
import "./assets/css/font-awesome.css";

// 引入分离出去的按需引入的vant组件
// 会导出一个含有insall方法的对象
import MyVant from "./components/vant/index.js";
// use函数会默认去调用install方法
Vue.use(MyVant);

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
