// let pxtorem = require("postcss-pxtorem");
// module.exports=  ({ file }) => {
//     let rootValue;
//     if (file && file.dirname && file.dirname.indexOf('vant') > -1) {
//         // vant采用375的设计稿，rem基准值为37.5；
//         rootValue = 37.5;
//     } else {
//         // 我们自己的设计稿为750，rem的基准值为75；
//         // 注意要和flexible.js中的基准值对应。
//         rootValue = 75;
//     }
//     return {
//         plugins: [
//             pxtorem({
//                 rootValue: rootValue,
//                 propList: ['*'],
//                 minPixelValue: 2
//             })
//         ]
//     }
// }